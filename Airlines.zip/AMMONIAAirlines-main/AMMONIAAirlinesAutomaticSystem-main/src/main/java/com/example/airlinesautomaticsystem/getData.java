package com.example.airlinesautomaticsystem;

public class getData {
    public static String username;
    public static String path;
}
